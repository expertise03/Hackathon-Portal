import { fieldNames, arrayField, singleField } from '../../hackportal.config';
export const singleFields = singleField;

export const arrayFields = arrayField;

export const fieldToName = fieldNames;
