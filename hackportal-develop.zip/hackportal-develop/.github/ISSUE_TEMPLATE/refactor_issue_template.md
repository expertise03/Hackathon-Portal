---
name: Refactor
about: Outline and track code that needs to be refactored.
title: '[Refactor] '
labels: ['Type: Refactor', 'Status: Awaiting Triage']
assignees:
---

# Overview

[Why is this refactor happening? Describe the motivations.]

# What Needs to Change

[Specify all files that will be changed.]
