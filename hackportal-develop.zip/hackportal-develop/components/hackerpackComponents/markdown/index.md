# General 💻

## Food 🌮

Lorem ipsum dolor sit amet, **consectetur adipiscing** elit, sed do eiusmod tempor *incididunt ut labore* et dolore magna aliqua. Morbi tempus iaculis urna id volutpat lacus laoreet non curabitur. Eget aliquet nibh praesent tristique. In est ante in nibh mauris. Imperdiet dui accumsan sit amet nulla facilisi morbi. Sed pulvinar proin gravida hendrerit lectus a.

Cursus mattis molestie a iaculis at. Fusce ut placerat orci nulla pellentesque dignissim enim sit amet. Placerat orci nulla pellentesque dignissim enim sit amet venenatis. Dolor magna eget est lorem [ipsum dolor sit](https://github.com/acmutd/hackportal).

| Location               | Distance | Cost |
|------------------------|----------|------|
| **Taco Bell**          | 0.5mi    | $    |
| **Joe's Crab Shack**   | 1.2mi    | $$   |
| **The Capital Grille** | 20mi     | $$$  |

## Mentors 🧑‍🏫

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Et eu et vitae, in quis metus quam integer et. Luctus elit cursus a habitasse velit. Egestas nisi, vel, sodales proin vitae quam aenean ullamcorper. Fames enim nunc augue velit nunc neque, fermentum odio elementum.

Luctus elit cursus a habitasse velit. Egestas nisi, vel, sodales proin vitae quam aenean ullamcorper. Fames enim nunc augue velit nunc neque, fermentum odio elementum.

- Luctus elit cursus
- A habitasse velit
- Egestas nisi
- Vel Sodales proin vitae

# Tech Workshop Packs 🤖

## Name of Workshop 1 🛒

Arcu dui vivamus arcu felis bibendum ut tristique et egestas. Mauris nunc congue nisi vitae suscipit. Vestibulum morbi blandit cursus risus at ultrices mi tempus imperdiet. Mi proin sed libero enim sed. Sit amet nisl suscipit adipiscing bibendum. Enim sit amet venenatis urna cursus eget. Est lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu. Enim nulla aliquet porttitor lacus luctus accumsan tortor.

## Name of Workshop 2 ☁️

Arcu dui vivamus arcu felis bibendum ut tristique et egestas. Mauris nunc congue nisi vitae suscipit. Vestibulum morbi blandit cursus risus at ultrices mi tempus imperdiet. Mi proin sed libero enim sed. Sit amet nisl suscipit adipiscing bibendum. Enim sit amet venenatis urna cursus eget. Est lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu. Enim nulla aliquet porttitor lacus luctus accumsan tortor.

## Name of Workshop 3 ‼️

Turpis egestas pretium aenean pharetra magna. Turpis in eu mi bibendum neque egestas congue quisque egestas. Egestas fringilla phasellus faucibus scelerisque. Tincidunt ornare massa eget egestas purus viverra accumsan in. Elit ut aliquam purus sit. Interdum varius sit amet mattis vulputate enim nulla. Lacinia quis vel eros donec ac odio.

- Cu erat prompta his
- A habitasse velit
- Duis at tellus at urna
- Egestas nisi

# Sponsor Workshop Packs 💵

## Name of Workshop 4 😆

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Et eu et vitae, in quis metus quam integer et. Luctus elit cursus a habitasse velit. Egestas nisi, vel, sodales proin vitae quam aenean ullamcorper. Fames enim nunc augue velit nunc neque, fermentum odio elementum.

Lacinia quis vel eros donec ac odio tempor orci. Mauris cursus mattis molestie a iaculis at. Ipsum dolor sit amet consectetur adipiscing elit duis. Integer vitae justo eget magna fermentum. Leo in vitae turpis massa sed elementum tempus.
